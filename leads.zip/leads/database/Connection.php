<?php
class Connection
{
    private $connect = '';

    function __construct()
    {
        $this->database_connection();
    }

    function database_connection()
    {
        $this->connect = new PDO("mysql:host=localhost;dbname=lindo_api", "root", "");
    }

    function fetchAll()
    {
        $query = "SELECT * FROM lindoapi ORDER BY id";
        $statement = $this->connect->prepare($query);
        if ($statement->execute()) {
            while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
                $data[] = $row;
            }
            return $data;
        }
    }

    function createAccount($user)
    {
        try {
            // inserting data into create table using prepare statement to prevent from sql injections
            $sql = "INSERT INTO users (username, password) VALUES (:username, :password)";
            $statement = $this->connect->prepare($sql);

            //hash password for security reasons
            $hashedPassword = password_hash($user->getPassword(), PASSWORD_DEFAULT);

            // inserting a record
            $statement->execute(array(':username' => $user->getUsername(), ':password' => $hashedPassword));
            return "New user created successfully";
        } catch (Exception $ex) {
            return "There is some problem in connection: " . $ex->getMessage();
        }
    }

    function insert($client)
    {
        try {
            // inserting data into create table using prepare statement to prevent from sql injections
            $sql = "INSERT INTO lindoapi (first_name, last_name) VALUES (:firstName, :lastName)";
            $statement = $this->connect->prepare($sql);

            // inserting a record
            $statement->execute(array(':firstName' => $client->getFirstName(), ':lastName' => $client->getLastName()));
            return "New record created successfully";
        } catch (Exception $ex) {
            return "There is some problem in connection: " . $ex->getMessage();
        }
    }

    function fetchById($id)
    {
        try {
            $query = "SELECT * FROM lindoapi WHERE id='" . $id . "'";
            $statement = $this->connect->prepare($query);
            if ($statement->execute()) {
                $data = array("message" => "Client with ID " . $id . " not found.");
                foreach ($statement->fetchAll() as $row) {
                    $data['first_name'] = $row['first_name'];
                    $data['last_name'] = $row['last_name'];
                }

                return $data;
            }
        } catch (Exception $ex) {
            return array("message" => $ex->getMessage());
        }
    }

    function update($client, $id)
    {
        $message = "";
        try {
            $sql = "UPDATE lindoapi SET first_name = \"" . $client->getFirstName() . "\" , last_name = \"" . $client->getLastName() . "\" WHERE id = " . $id;
            $affectedRows  = $this->connect->exec($sql);

            /*   
                exec returns
                :1 if oldValue is not the same with newValue
                :0 if oldValue is the same with newValue 
                :false if not update was performed at all
            */
            var_dump($affectedRows);
            if ($affectedRows) {
                $message = "Record has been successfully updated ";
            } else {
                $message = "Record not updated ";
            }
        } catch (Exception $ex) {
            $message = $ex->getMessage();
        }
        return $message;
    }
    function deleteById($id)
    {
        $message = "";
        try {
            $query = "DELETE FROM lindoapi WHERE id = '" . $id . "'";
            $statement = $this->connect->prepare($query);
            $result = $statement->execute();

            if ($result) {
                $message = "Client successfully deleted.";
            } else {
                $message = "Client deletion not successful";
            }
        } catch (Exception $ex) {
            $message = "Error occured while deleting. " . $ex->getMessage();
        }
        return array("message" => $message);
    }
}
