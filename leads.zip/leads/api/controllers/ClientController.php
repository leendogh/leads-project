<?php
include '../viewmodels/ClientView.php';
include '../actions/action.php';

$firstName = '';
$lastName = '';
if (isset($_POST['firstName']) && isset($_POST['lastName'])) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
}


switch ($query) {
    case "createClient":
        $clientView = new ClientView();
        $client  = $clientView->createClient($firstName, $lastName);
        $status = $clientView->saveClient($client);
        echo  json_encode($status);
        break;
    case "findAll":
        $clientView = new ClientView();
        $clients = $clientView->fetchAllClients();
        echo json_encode($clients);
        break;
    case "findById":
        $clientView = new ClientView();
        if (!empty($_GET['id'])) {
            $clients = $clientView->fetchById($_GET['id']);
            echo json_encode($clients);
        } else {
            echo json_encode(array("message" => "Error fetching client"));
        }
        break;
    case "update":
        $clientView = new ClientView();
        if (!empty($_GET['id'])) {
            $client  = $clientView->createClient($firstName, $lastName);
            $status = $clientView->updateClient($client, $_GET['id']);
            echo  json_encode($status);
        } else {
            echo json_encode(array("message" => "Error updating client"));
        }
        break;
    case "deleteById":
        $clientView = new ClientView();
        if (!empty($_GET['id'])) {
            $clients = $clientView->fetchById($_GET['id']);
            echo json_encode($clients);
        } else {
            echo json_encode(array("message" => "Error fetching client"));
        }
        break;
    default:
        echo "Invalid option";
}
