<?php
include '../viewmodels/UserView.php';
include '../actions/action.php';

$username = '';
$password = '';
$passwordConfirmation = '';
if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['passwordConfirmation'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $passwordConfirmation = $_POST['passwordConfirmation'];
}


switch ($query) {
    case "registration":
        $userView = new UserView();
        $user  = $userView->createUser($username, $password, $passwordConfirmation);
        if ($password === $passwordConfirmation) {
            if (!empty($username)) {
                $status = $userView->registration($user);
                echo  json_encode($status);
            } else {
                echo  json_encode(array("messaagex" => "Username field is required"));
            }
        } else {
            echo  json_encode(array("messaagex" => "Passwords do not match"));
        }

        break;
    default:
        echo "Invalid option";
}
