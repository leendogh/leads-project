<?php

class User
{
    private $username;
    private $password;
    private $passwordConfirmation;

    public function setUsername($username)
    {
        $this->username = $username;
    }

    public function getUsername()
    {
        return $this->username;
    }

    public function setPassword($password)
    {
        $this->password = $password;
    }

    public function getPassword()
    {
        return $this->password;
    }

    public function setPasswordConfirmation($passwordConfirmation)
    {
        $this->passwordConfirmation = $passwordConfirmation;
    }

    public function getPasswordConfirmation()
    {
        return $this->passwordConfirmation;
    }

    public function __toString()
    {
        try 
        {
            return $this->username;
        } 
        catch (Exception $exception) 
        {
            return '';
        }
    }
}
