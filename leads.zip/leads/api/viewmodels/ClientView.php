<?php

include '../models/Client.php';
include '../../database/Connection.php';

class ClientView
{
    function __construct()
    { }

    function createClient($firstName, $lastName)
    {
        $client = new Client();
        $client->setFirstName($firstName);
        $client->setLastName($lastName);
        return $client;
    }

    function registration($user)
    {
        $status = '';

        $connection = new Connection();
        $status = $connection->createAccount($user);

        return array("message" => $status);
    }


    function saveClient($clientObject)
    {
        $status = '';

        $connection = new Connection();
        $status = $connection->insert($clientObject);

        return array("message" => $status);
    }

    function updateClient($clientObject, $id)
    {
        $status = '';

        $connection = new Connection();
        $status = $connection->update($clientObject, $id);


        return array("message" => $status);
    }

    function fetchAllClients()
    {
        $connection = new Connection();
        $clients = $connection->fetchAll();
        return $clients;
    }

    function fetchById($id)
    {
        $connection = new Connection();
        $client = $connection->fetchById($id);
        return $client;
    }

    function deletehById($id)
    {
        $connection = new Connection();
        $client = $connection->deleteById($id);
        return $client;
    }
}
