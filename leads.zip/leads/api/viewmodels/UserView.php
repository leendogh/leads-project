<?php

include '../models/User.php';
include '../../database/Connection.php';

class UserView
{
    function __construct()
    { }

    function createUser($username, $password, $passwordConfirmation)
    {
        $message = '';
        if (
            !empty($username)
            && !empty($password)
            && !empty($passwordConfirmation)
        ) {

            $user = new User();
            $user->setUsername($username);
            $user->setPassword($username);
            return $user;
        } else {
            $message = "All fields must be supplied";
        }
    }

    function registration($user)
    {
        $status = '';

        $connection = new Connection();
        $status = $connection->createAccount($user);

        return array("message" => $status);
    }
}
