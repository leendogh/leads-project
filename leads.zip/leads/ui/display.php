<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"
integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="css/main_css.css">
</head>
<body>
    <button id="loadData">Load Data</button>
    <div id="display"></div>
    <script>
        $("#loadData").click(function () {
            $.get("http://localhost/leads/api/controllers/ClientController.php?action=findAll", function (data, status) {
                var clients = JSON.parse(data);
                //console.log(clients);
                var str = '<ul>'
                for (var a = 0; a < clients.length; a++) {
                    console.log(clients[a]);
                    str += '<li>' + clients[a].first_name + '' + clients[a].last_name + '</li>';
                }
                str += '</ul>';
                document.getElementById("display").innerHTML = str;
            });
        });
    </script>
</body>

</html>